#!/bin/bash

# run.sh - Master script to install requirements and run both BeEF and Bettercap setup

echo "[*] Installing required packages..."
sudo apt update
sudo apt install -y bettercap beef-xss python3 python3-pip

echo "[*] Checking for required Python packages..."
pip3 install --user http.server >/dev/null 2>&1 || true

echo "[*] Giving execute permission to scripts..."
chmod +x beef-launcher.sh bettercap-injector.sh

echo "[*] Launching beef-launcher.sh in a new terminal session..."
gnome-terminal -- bash -c "./beef-launcher.sh; exec bash" 2>/dev/null || xterm -e "./beef-launcher.sh" &

sleep 5

echo "[*] Launching bettercap-injector.sh in a new terminal session..."
gnome-terminal -- bash -c "./bettercap-injector.sh; exec bash" 2>/dev/null || xterm -e "./bettercap-injector.sh" &

echo "[+] Both scripts launched in separate sessions."
